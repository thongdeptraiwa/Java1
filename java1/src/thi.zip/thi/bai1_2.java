/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thi;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author macos
 */
public class bai1_2 {
    private static ArrayList<Integer> list = new ArrayList<Integer>();
    private static Scanner sc = new Scanner(System.in);
    public static void nhap(){
        for(int i=0;i<3;i++){
            System.out.printf("Nhap A[%d]: ",i);
            list.add(Integer.parseInt(sc.nextLine()));
        }
    }
    public static void dem(){
        int demchan=0,demle=0;
        
        for(int i=0;i<3;i++){
            if(list.get(i)%2==0){
                demchan++;
            }
            else{
                demle++;
            }
        }   
        System.out.printf("co %d so chan\n ",demchan);
        System.out.printf("co %d so  le\n ",demle);
    }
    public static void ngto(){
        boolean kt=true;
        System.out.println("Danh sach so nguyen to :");
        for(int i=0;i<3;i++){
            for(int j=2;j<list.get(i)-1;j++){
                if(list.get(i)%j==0){
                    kt=false;
                    break;
                }
            }
            if(kt==true){
                System.out.println(list.get(i));
            }
            kt=true;
        }
    }
    public static void main(String[] args) {
        int chon;
        nhap();
        do{
            
            System.out.println("\n\tMenu");
            System.out.println("1/dem chan va le");
            System.out.println("2/cac so nguyen to");
            System.out.println("3/thoat");
            System.out.print("Vui long chon: ");
            chon = Integer.parseInt(sc.nextLine());
            switch(chon){
                case 1:{
                    dem();
                    break;
                }
                case 2:{
                    ngto();
                    break;
                }
                case 3:{
                    System.out.println("Bye bye");
                    System.exit(0);
                }
                default:{
                    System.out.println("Ban da nhap sai!");
                    continue;
                }
            }
        }while(true);
    }
}
