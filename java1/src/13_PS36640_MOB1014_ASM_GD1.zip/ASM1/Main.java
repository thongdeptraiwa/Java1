/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ASM;
import constanst.UtilsConstanst;

/**
 *
 * @author macos
 */
public class Main {

    public static int menu() {
        System.out.println("                            *Menu*            ");
        System.out.println("+----------------------------------------------------------+");
        System.out.println("| 1. Nhap danh sach nhan vien tu ban phim                  |");
        System.out.println("| 2. Xuat danh sach nhan vien ra man hinh                  |");
        System.out.println("| 3. Tim va hien thi nhan vien theo ma nhap tu ban phim    |");
        System.out.println("| 4. Xoa nhan vien theo ma nhap tu ban phim                |");
        System.out.println("| 5. Cap nhat thong tin nhan vien theo ma nhap tu ban phim |");
        System.out.println("| 6. Tim cac nhan vien theo khoang luong nhap tu ban phim  |");
        System.out.println("| 7. Sap xep nhan vien theo ho va tien                     |");
        System.out.println("| 8. sap xep nhan vien theo thu nhap                       |");
        System.out.println("| 9. Xuat 5 nhan vien co thu nhap cao nhat                 |");
        System.out.println("| 10. Thoat chuong trinh                                   |");
        System.out.println("+----------------------------------------------------------+");
        System.out.printf("\t\t\tVui long chon: ");
        int chon = UtilsConstanst.nhap.nextInt();
        return chon;
    }

    public static void main(String[] args) {
        int chon;
        do {
            chon = menu();
            switch (chon) {
                case 1: {
                    Cau1.cau1();
                    break;
                }
                case 2: {
                    Cau2.cau2();
                    break;
                }
                case 3: {
                    Cau3.cau3();
                    break;
                }
                case 4: {   
                    Cau4.cau4();
                    break;
                }
                case 5: {
                    Cau5.cau5();
                    break;
                }
                case 6: {
                    Cau6.cau6();
                    break;
                }
                case 7: {
                    Cau7.cau7();
                    break;
                }
                case 8: {
                    Cau8.cau8();
                    break;
                }
                case 9: {
                    Cau9.cau9();
                    break;
                }
                case 10: {
                    System.out.println("Bye Bye");
                    System.exit(0);
                }
            }
        } while (true);

    }
}
