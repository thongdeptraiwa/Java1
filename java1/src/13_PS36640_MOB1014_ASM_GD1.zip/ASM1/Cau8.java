/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ASM;

/**
 *
 * @author macos
 */
public class Cau8 {
    public static void cau8(){
        System.out.println("cau 8");
    }
}
