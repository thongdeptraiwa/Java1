/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
import java.util.Scanner;
/**
 *
 * @author macos
 */
public class bai2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.printf("Nhap chieu dai: ");
        double chieuDai = scanner.nextDouble();
        System.out.printf("Nhap chieu rong: ");
        double chieuRong = scanner.nextDouble();
        double cv = ( chieuDai + chieuRong ) * 2;
        double dt = chieuDai * chieuRong;
        System.out.printf("Chu vi: %.2f \n Dien tich: %.2f\n",cv,dt);
        System.out.printf("Canh nho nhat: %.2f\n",Math.min(chieuDai,chieuRong));
        
    }
}
