/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
import java.util.Scanner;
/**
 *
 * @author macos
 */
public class bai5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Nhap a: ");
        double a = sc.nextDouble();
        System.out.printf("Nhap b: ");
        double b = sc.nextDouble();
        System.out.printf("Nhap c: ");
        double c = sc.nextDouble();
        /*if(a+b>c || a+c>b || b+c>a ) 
            System.out.println("dung");
        else    
            System.out.println("Sai");*/
        String kt = (a+b>c && a+c>b && b+c>a ) ? "dung" : "sai";
        System.out.println(kt);
    }
}
