/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;
import java.util.Scanner;
/**
 *
 * @author macos
 */
public class bai4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Nhap a: ");
        double a = sc.nextDouble();
        System.out.printf("Nhap b: ");
        double b = sc.nextDouble();
        System.out.printf("Nhap c: ");
        double c = sc.nextDouble();
        double delta = Math.pow(b,2)-4*a*c;
        System.out.printf("Delta: %.2f\nCan Delta: %.2f\n",delta,Math.sqrt(delta));
    }
}
