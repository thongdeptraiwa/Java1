/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author macos
 */
public class Bai1 {
    public static void main(String[] args) {
        ChuNhat h1 = new ChuNhat(5,6);
        ChuNhat h2 = new Vuong(3);
        h1.xuat();
        h2.xuat();
    }
}
